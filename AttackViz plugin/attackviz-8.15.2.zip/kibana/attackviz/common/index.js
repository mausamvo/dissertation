"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.PLUGIN_NAME = exports.PLUGIN_ID = void 0;
const PLUGIN_ID = exports.PLUGIN_ID = 'attackviz';
const PLUGIN_NAME = exports.PLUGIN_NAME = 'attackviz';
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJQTFVHSU5fSUQiLCJleHBvcnRzIiwiUExVR0lOX05BTUUiXSwic291cmNlcyI6WyJpbmRleC50cyJdLCJzb3VyY2VzQ29udGVudCI6WyJleHBvcnQgY29uc3QgUExVR0lOX0lEID0gJ2F0dGFja3Zpeic7XG5leHBvcnQgY29uc3QgUExVR0lOX05BTUUgPSAnYXR0YWNrdml6JztcbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7O0FBQU8sTUFBTUEsU0FBUyxHQUFBQyxPQUFBLENBQUFELFNBQUEsR0FBRyxXQUFXO0FBQzdCLE1BQU1FLFdBQVcsR0FBQUQsT0FBQSxDQUFBQyxXQUFBLEdBQUcsV0FBVyIsImlnbm9yZUxpc3QiOltdfQ==