"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.plugin = plugin;
function _getRequireWildcardCache(e) { if ("function" != typeof WeakMap) return null; var r = new WeakMap(), t = new WeakMap(); return (_getRequireWildcardCache = function (e) { return e ? t : r; })(e); }
function _interopRequireWildcard(e, r) { if (!r && e && e.__esModule) return e; if (null === e || "object" != typeof e && "function" != typeof e) return { default: e }; var t = _getRequireWildcardCache(r); if (t && t.has(e)) return t.get(e); var n = { __proto__: null }, a = Object.defineProperty && Object.getOwnPropertyDescriptor; for (var u in e) if ("default" !== u && {}.hasOwnProperty.call(e, u)) { var i = a ? Object.getOwnPropertyDescriptor(e, u) : null; i && (i.get || i.set) ? Object.defineProperty(n, u, i) : n[u] = e[u]; } return n.default = e, t && t.set(e, n), n; }
//  This exports static code and TypeScript types,
//  as well as, Kibana Platform `plugin()` initializer.

async function plugin(initializerContext) {
  const {
    AttackvizPlugin
  } = await Promise.resolve().then(() => _interopRequireWildcard(require('./plugin')));
  return new AttackvizPlugin(initializerContext);
}
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJwbHVnaW4iLCJpbml0aWFsaXplckNvbnRleHQiLCJBdHRhY2t2aXpQbHVnaW4iLCJQcm9taXNlIiwicmVzb2x2ZSIsInRoZW4iLCJfaW50ZXJvcFJlcXVpcmVXaWxkY2FyZCIsInJlcXVpcmUiXSwic291cmNlcyI6WyJpbmRleC50cyJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgdHlwZSB7IFBsdWdpbkluaXRpYWxpemVyQ29udGV4dCB9IGZyb20gJ0BrYm4vY29yZS9zZXJ2ZXInO1xuXG4vLyAgVGhpcyBleHBvcnRzIHN0YXRpYyBjb2RlIGFuZCBUeXBlU2NyaXB0IHR5cGVzLFxuLy8gIGFzIHdlbGwgYXMsIEtpYmFuYSBQbGF0Zm9ybSBgcGx1Z2luKClgIGluaXRpYWxpemVyLlxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gcGx1Z2luKGluaXRpYWxpemVyQ29udGV4dDogUGx1Z2luSW5pdGlhbGl6ZXJDb250ZXh0KSB7XG4gIGNvbnN0IHsgQXR0YWNrdml6UGx1Z2luIH0gPSBhd2FpdCBpbXBvcnQoJy4vcGx1Z2luJyk7XG4gIHJldHVybiBuZXcgQXR0YWNrdml6UGx1Z2luKGluaXRpYWxpemVyQ29udGV4dCk7XG59XG5cbmV4cG9ydCB0eXBlIHsgQXR0YWNrdml6UGx1Z2luU2V0dXAsIEF0dGFja3ZpelBsdWdpblN0YXJ0IH0gZnJvbSAnLi90eXBlcyc7XG4iXSwibWFwcGluZ3MiOiI7Ozs7Ozs7O0FBRUE7QUFDQTs7QUFFTyxlQUFlQSxNQUFNQSxDQUFDQyxrQkFBNEMsRUFBRTtFQUN6RSxNQUFNO0lBQUVDO0VBQWdCLENBQUMsR0FBRyxNQUFBQyxPQUFBLENBQUFDLE9BQUEsR0FBQUMsSUFBQSxPQUFBQyx1QkFBQSxDQUFBQyxPQUFBLENBQWEsVUFBVSxHQUFDO0VBQ3BELE9BQU8sSUFBSUwsZUFBZSxDQUFDRCxrQkFBa0IsQ0FBQztBQUNoRCIsImlnbm9yZUxpc3QiOltdfQ==